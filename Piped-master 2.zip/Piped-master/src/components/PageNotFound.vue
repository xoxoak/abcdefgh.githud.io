<template>
    <div class="flex flex-col justify-center items-center min-h-[88vh]">
        <h1 class="font-bold !text-9xl">404</h1>
        <h2 class="!text-2xl" v-t="'info.page_not_found'" />
        <a class="btn mt-16" href="/" v-t="'actions.back_to_home'" />
    </div>
</template>
